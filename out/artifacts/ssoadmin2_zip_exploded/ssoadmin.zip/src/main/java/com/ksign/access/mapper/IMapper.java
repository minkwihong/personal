package com.ksign.access.mapper;

public interface IMapper {

}
