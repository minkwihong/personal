/*
공통 service js
 */

var commonService = function () {};

commonService.prototype.search = function (context , methodId , keyName, keyValue) {

    var order_by = $("#sortType").val();
    var sortType = $("#sortType").attr("data-sorttype");
    var v_methodId = "";
    var paramObj = {};

    if(isList(methodId)){
        paramObj = {
            orderBy : order_by + " " + sortType, // using defualt
            pageSize : pageSize,
            pageNo : parseInt($("#curPage").val())
        }
        paramObj[order_by] = encodeURIComponent($("#s_value").val())

        v_methodId = '/' + methodId;
    }else{
        var key  = keyName ;
        paramObj = {};

        paramObj[key] = keyValue

        v_methodId = '/' + methodId;
    }

    handleGet( context +  v_methodId , paramObj, initSucess);
};

commonService.prototype.regist = function (context, serviceId ,formName) {

    var formName = "#" + formName;

    if($('#isDupl').val() == 'false'){
        alert('중복체크를 확인이 필요합니다.');
        return;
    };
    var paramObj = $(formName).serializeObject();

    handlePost( context + "/" + serviceId + "Regist", paramObj , registSuccess, registError);
};

commonService.prototype.modify = function (context, serviceId ,formName) {

    var formName = "#" + formName;
    var paramObj = $(formName).serializeObject();

    handlePatch( context + "/" + serviceId  + "Update", paramObj , modifySuccess, modifyError);
};

commonService.prototype.delete = function () {


};

commonService.prototype.duplCheck = function (context, serviceId ,keyname) {
    var key  = keyname ;
    var paramObj = {};

    paramObj[key] = $('#' + keyname).val()

    handleGet( context + "/" + serviceId + "DuplCheck", paramObj , duplSuccess , duplError);

};


